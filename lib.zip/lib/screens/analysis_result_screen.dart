import 'package:flutter/material.dart';
import '../services/speech_analysis_service.dart';
import '../services/cefr_scoring_service.dart';
import 'settings_screen.dart';

class AnalysisResultScreen extends StatefulWidget {
  final String audioPath;
  final String title;

  const AnalysisResultScreen({
    super.key,
    required this.audioPath,
    required this.title,
  });

  @override
  State<AnalysisResultScreen> createState() => _AnalysisResultScreenState();
}

class _AnalysisResultScreenState extends State<AnalysisResultScreen> {
  final _service = SpeechAnalysisService();
  final _cefrService = CefrScoringService();
  SpeechMetrics? _metrics;
  String? _error;
  int _progress = 0;

  CefrScoreResult? _cefrResult;
  bool _cefrLoading = false;
  String? _cefrError;

  @override
  void initState() {
    super.initState();
    _run();
  }

  Future<void> _run() async {
    try {
      final metrics = await _service.analyze(
        widget.audioPath,
        onProgress: (p) {
          if (mounted) setState(() => _progress = p);
        },
      );
      if (mounted) setState(() => _metrics = metrics);
    } catch (e) {
      if (mounted) {
        setState(() => _error = 'Could not analyze this recording.\n$e');
      }
    }
  }

  Future<void> _runCefrScoring() async {
    if (_metrics == null) return;
    setState(() {
      _cefrLoading = true;
      _cefrError = null;
    });
    try {
      final apiKey = await SettingsScreen.loadApiKey();
      final result = await _cefrService.score(
        apiKey: apiKey,
        transcript: _metrics!.transcript,
        wpm: _metrics!.wpm,
        fillerCount: _metrics!.totalFillers,
        longPauseCount: _metrics!.longPauseTimestamps.length,
        lexicalDiversity: _metrics!.correctedTtr,
        advancedWordRatio: _metrics!.advancedWordRatio,
      );
      if (mounted) setState(() => _cefrResult = result);
    } catch (e) {
      if (mounted) setState(() => _cefrError = e.toString());
    } finally {
      if (mounted) setState(() => _cefrLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Analysis: ${widget.title}'),
        backgroundColor: Colors.lightBlue,
        foregroundColor: Colors.white,
      ),
      body: _error != null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(_error!, textAlign: TextAlign.center),
              ),
            )
          : _metrics == null
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const CircularProgressIndicator(),
                      const SizedBox(height: 16),
                      Text('Transcribing on-device… $_progress%'),
                      const SizedBox(height: 4),
                      const Text(
                        'First run may take longer while the model loads.',
                        style: TextStyle(color: Colors.grey, fontSize: 12),
                      ),
                    ],
                  ),
                )
              : _buildResults(_metrics!),
    );
  }

  Widget _buildResults(SpeechMetrics m) {
    final paceColor = m.paceInRange ? Colors.green : Colors.orange;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _metricCard(
          title: 'Speaking Pace',
          color: paceColor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${m.wpm.toStringAsFixed(0)} WPM',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: paceColor,
                ),
              ),
              Text(m.paceLabel),
              const SizedBox(height: 4),
              Text(
                'Target range: ${SpeechMetrics.targetWpmMin}–${SpeechMetrics.targetWpmMax} wpm',
                style: const TextStyle(color: Colors.grey, fontSize: 12),
              ),
            ],
          ),
        ),
        _metricCard(
          title: 'Filler Words',
          color: m.totalFillers == 0 ? Colors.green : Colors.redAccent,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${m.totalFillers} total',
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              if (m.fillerCounts.isNotEmpty) ...[
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: m.fillerCounts.entries
                      .map((e) => Chip(label: Text('"${e.key}" ×${e.value}')))
                      .toList(),
                ),
              ],
            ],
          ),
        ),
        _metricCard(
          title: 'Long Pauses (> 2s)',
          color: m.longPauseTimestamps.isEmpty ? Colors.green : Colors.amber[800]!,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${m.longPauseTimestamps.length} detected',
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              if (m.longPauseTimestamps.isNotEmpty) ...[
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: m.longPauseTimestamps
                      .map((t) => Chip(label: Text(_fmt(t))))
                      .toList(),
                ),
              ],
            ],
          ),
        ),
        _metricCard(
          title: 'Vocabulary Range',
          color: Colors.blue,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${m.vocabularyHits.length} academic/B2-C1 terms used',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              if (m.vocabularyHits.isEmpty)
                const Text(
                  'Try weaving in transition markers like "furthermore" or "on the other hand".',
                  style: TextStyle(color: Colors.grey),
                )
              else
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: m.vocabularyHits
                      .map((v) => Chip(
                            backgroundColor: Colors.blue.shade50,
                            label: Text(v),
                          ))
                      .toList(),
                ),
            ],
          ),
        ),
        _metricCard(
          title: 'Lexical Diversity & Word Frequency',
          color: Colors.teal,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${m.uniqueWordCount} unique words out of ${m.wordCount}',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              Text(m.lexicalDiversityLabel, style: const TextStyle(color: Colors.black87)),
              const SizedBox(height: 4),
              Text(
                'Type-token ratio: ${(m.typeTokenRatio * 100).toStringAsFixed(0)}%  •  '
                'Corrected TTR: ${m.correctedTtr.toStringAsFixed(1)}',
                style: const TextStyle(color: Colors.grey, fontSize: 12),
              ),
              const SizedBox(height: 12),
              const Text('Word frequency bands', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
              const SizedBox(height: 6),
              _bandBar(m),
              const SizedBox(height: 6),
              _bandLegend('Very common', Colors.teal.shade300, m.commonWordRatio),
              _bandLegend('Moderately common', Colors.teal.shade500, m.midWordRatio),
              _bandLegend('Less common / advanced', Colors.teal.shade800, m.advancedWordRatio),
              const SizedBox(height: 8),
              const Text(
                'Heuristic estimate from a short built-in word list, not a calibrated corpus lookup.',
                style: TextStyle(color: Colors.grey, fontSize: 11, fontStyle: FontStyle.italic),
              ),
            ],
          ),
        ),
        _metricCard(
          title: 'Transcript',
          color: Colors.grey,
          child: Text(m.transcript.isEmpty ? '(no speech detected)' : m.transcript),
        ),
        _buildCefrSection(m),
      ],
    );
  }

  Widget _buildCefrSection(SpeechMetrics m) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(color: Colors.deepPurple, shape: BoxShape.circle),
                ),
                const SizedBox(width: 8),
                const Text(
                  'CEFR LEVEL',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (_cefrResult == null && !_cefrLoading)
              ElevatedButton.icon(
                onPressed: m.transcript.trim().isEmpty ? null : _runCefrScoring,
                icon: const Icon(Icons.psychology_outlined, size: 18),
                label: const Text('Get CEFR Level (Gemini)'),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple, foregroundColor: Colors.white),
              ),
            if (_cefrLoading)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: Row(
                  children: [
                    SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
                    SizedBox(width: 12),
                    Text('Asking Gemini to score this…'),
                  ],
                ),
              ),
            if (_cefrError != null) ...[
              Text(_cefrError!, style: const TextStyle(color: Colors.redAccent)),
              const SizedBox(height: 8),
              TextButton(onPressed: _runCefrScoring, child: const Text('Retry')),
            ],
            if (_cefrResult != null) _buildCefrResultBody(_cefrResult!),
          ],
        ),
      ),
    );
  }

  Widget _buildCefrResultBody(CefrScoreResult r) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.deepPurple.shade50,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.deepPurple),
              ),
              child: Text(
                r.overallLevel,
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.deepPurple),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(child: Text(r.overallSummary)),
          ],
        ),
        const SizedBox(height: 12),
        ...r.dimensionList.map(
          (entry) => Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: 70,
                  child: Text(entry.key, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                ),
                Container(
                  margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(entry.value.level, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                ),
                Expanded(
                  child: Text(entry.value.justification, style: const TextStyle(fontSize: 13, color: Colors.black87)),
                ),
              ],
            ),
          ),
        ),
        if (r.strengths.isNotEmpty) ...[
          const SizedBox(height: 4),
          const Text('Strengths', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
          ...r.strengths.map((s) => Text('• $s', style: const TextStyle(fontSize: 13))),
        ],
        if (r.areasToImprove.isNotEmpty) ...[
          const SizedBox(height: 8),
          const Text('Areas to improve', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
          ...r.areasToImprove.map((s) => Text('• $s', style: const TextStyle(fontSize: 13))),
        ],
      ],
    );
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Widget _bandBar(SpeechMetrics m) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(6),
      child: SizedBox(
        height: 14,
        child: Row(
          children: [
            Expanded(flex: (m.commonWordRatio * 1000).round().clamp(0, 1000), child: Container(color: Colors.teal.shade300)),
            Expanded(flex: (m.midWordRatio * 1000).round().clamp(0, 1000), child: Container(color: Colors.teal.shade500)),
            Expanded(flex: (m.advancedWordRatio * 1000).round().clamp(1, 1000), child: Container(color: Colors.teal.shade800)),
          ],
        ),
      ),
    );
  }

  Widget _bandLegend(String label, Color color, double ratio) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          Container(width: 10, height: 10, color: color),
          const SizedBox(width: 8),
          Expanded(child: Text(label, style: const TextStyle(fontSize: 12))),
          Text('${(ratio * 100).toStringAsFixed(0)}%', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _metricCard({
    required String title,
    required Color color,
    required Widget child,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                ),
                const SizedBox(width: 8),
                Text(
                  title.toUpperCase(),
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            child,
          ],
        ),
      ),
    );
  }
}