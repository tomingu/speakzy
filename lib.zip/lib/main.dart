import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:record/record.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'screens/analysis_result_screen.dart';
import 'screens/settings_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MuetTimerApp());
}

class MuetTimerApp extends StatelessWidget {
  const MuetTimerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MUET Recording Timer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const MainNavigationScreen(),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;
  final List<File> _recordings = [];

  void _addRecording(File file) {
    setState(() {
      _recordings.insert(0, file);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: switch (_currentIndex) {
        0 => TimerScreen(onRecordingSaved: _addRecording),
        1 => RecordingsListScreen(recordings: _recordings),
        _ => const SettingsScreen(),
      },
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.timer),
            label: 'Timer',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.list_alt),
            label: 'List',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}

class IntervalStage {
  final String title;
  final int durationSeconds;
  final String transitionPhrase;

  IntervalStage({
    required this.title,
    required this.durationSeconds,
    required this.transitionPhrase,
  });
}

/// A bank of past-year style MUET Part 1 individual presentation prompts.
const List<String> kMuetTopicBank = [
  'Describe a time you helped someone and how it made you feel.',
  'Talk about the advantages and disadvantages of social media for teenagers.',
  'Describe your favourite place to relax and explain why.',
  'Discuss the importance of teamwork in the workplace.',
  'Talk about a skill you would like to learn and why it matters to you.',
  'Describe the impact of technology on education.',
  'Discuss the benefits of reading books compared to watching movies.',
  'Talk about your future career plans and how you intend to achieve them.',
  'Describe a memorable trip you have taken.',
  'Discuss the importance of environmental conservation.',
  'Talk about the role of family in personal development.',
  'Describe a challenge you overcame and what you learned from it.',
];

/// How much scaffolding (beeps + on-screen cues) Ghost Mode allows through,
/// based on how many full attempts the student has completed.
enum GhostLevel { full, visualOnly, silent }

class TimerScreen extends StatefulWidget {
  final Function(File) onRecordingSaved;

  const TimerScreen({super.key, required this.onRecordingSaved});

  @override
  State<TimerScreen> createState() => _TimerScreenState();
}

class _TimerScreenState extends State<TimerScreen> {
  // 15s -> 30s -> 30s -> 30s -> 15s (Total: 120s / 2 Minutes)
  final List<IntervalStage> _stages = [
    IntervalStage(
      title: 'Introduction',
      durationSeconds: 15,
      transitionPhrase: 'Good day. I would like to talk about...',
    ),
    IntervalStage(
      title: 'Point 1',
      durationSeconds: 30,
      transitionPhrase: "Let's start with my first point...",
    ),
    IntervalStage(
      title: 'Point 2',
      durationSeconds: 30,
      transitionPhrase: 'Moving on to my next point...',
    ),
    IntervalStage(
      title: 'Point 3',
      durationSeconds: 30,
      transitionPhrase: 'Another important point to consider is...',
    ),
    IntervalStage(
      title: 'Conclusion',
      durationSeconds: 15,
      transitionPhrase: 'To conclude my presentation...',
    ),
  ];

  static const int totalDuration = 120;
  static const int prepDuration = 60;

  Timer? _timer;
  int _totalElapsedSeconds = 0;
  bool _isRunning = false;

  final AudioRecorder _audioRecorder = AudioRecorder();
  String? _tempAudioPath;

  // --- Ghost Mode (fading scaffolding) ---
  bool _ghostModeEnabled = false;
  int _attemptCount = 0;

  // --- Topic Generator + prep countdown ---
  final Random _random = Random();
  String? _currentTopic;
  bool _isPrepping = false;
  int _prepRemaining = prepDuration;
  Timer? _prepTimer;

  // --- Transition phrase banner ---
  String? _bannerText;
  Timer? _bannerTimer;

  @override
  void dispose() {
    _timer?.cancel();
    _prepTimer?.cancel();
    _bannerTimer?.cancel();
    _audioRecorder.dispose();
    super.dispose();
  }

  // Calculate which stage we are currently in
  int get _currentStageIndex {
    int accumulated = 0;
    for (int i = 0; i < _stages.length; i++) {
      accumulated += _stages[i].durationSeconds;
      if (_totalElapsedSeconds < accumulated) {
        return i;
      }
    }
    return _stages.length - 1;
  }

  // Calculate elapsed seconds inside the active stage
  int get _currentStageElapsedSeconds {
    int accumulated = 0;
    for (int i = 0; i < _stages.length; i++) {
      if (_totalElapsedSeconds < accumulated + _stages[i].durationSeconds) {
        return _totalElapsedSeconds - accumulated;
      }
      accumulated += _stages[i].durationSeconds;
    }
    return _stages.last.durationSeconds;
  }

  GhostLevel get _ghostLevel {
    if (!_ghostModeEnabled) return GhostLevel.full;
    if (_attemptCount < 2) return GhostLevel.full;
    if (_attemptCount < 4) return GhostLevel.visualOnly;
    return GhostLevel.silent;
  }

  String _formatTime(int seconds) {
    final m = (seconds ~/ 60).toString().padLeft(2, '0');
    final s = (seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Future<void> _startRecording() async {
    final status = await Permission.microphone.request();
    if (status != PermissionStatus.granted) return;

    final tempDir = await getTemporaryDirectory();
    _tempAudioPath =
        '${tempDir.path}/muet_temp_${DateTime.now().millisecondsSinceEpoch}.m4a';

    await _audioRecorder.start(
      const RecordConfig(encoder: AudioEncoder.aacLc),
      path: _tempAudioPath!,
    );
  }

  Future<void> _stopRecording() async {
    if (await _audioRecorder.isRecording()) {
      await _audioRecorder.stop();
    }
  }

  // The hard start/end buzzer always plays — this mirrors the real exam,
  // where the invigilator's bell is never faded out.
  void _triggerHardBeep() {
    SystemSound.play(SystemSoundType.alert);
    HapticFeedback.heavyImpact();
  }

  // Intermediate stage-transition beeps fade out under Ghost Mode.
  void _triggerStageBeep() {
    if (_ghostLevel == GhostLevel.full) {
      SystemSound.play(SystemSoundType.alert);
      HapticFeedback.heavyImpact();
    }
  }

  void _showTransitionBanner(String text) {
    if (_ghostLevel == GhostLevel.silent) return; // fully silent: no cue text
    _bannerTimer?.cancel();
    setState(() => _bannerText = text);
    _bannerTimer = Timer(const Duration(seconds: 4), () {
      if (mounted) setState(() => _bannerText = null);
    });
  }

  // --- Topic generator ---
  void _pickNewTopic() {
    if (_isRunning || _isPrepping) return;
    setState(() {
      _currentTopic = kMuetTopicBank[_random.nextInt(kMuetTopicBank.length)];
      _totalElapsedSeconds = 0;
    });
  }

  void _clearTopic() {
    if (_isRunning || _isPrepping) return;
    setState(() => _currentTopic = null);
  }

  void _startPrep() {
    if (_currentTopic == null || _isRunning || _isPrepping) return;
    setState(() {
      _isPrepping = true;
      _prepRemaining = prepDuration;
    });
    _prepTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_prepRemaining <= 1) {
        timer.cancel();
        setState(() {
          _isPrepping = false;
          _prepRemaining = 0;
        });
        _triggerHardBeep();
        _startTimer();
      } else {
        setState(() => _prepRemaining--);
      }
    });
  }

  void _cancelPrep() {
    _prepTimer?.cancel();
    setState(() {
      _isPrepping = false;
      _prepRemaining = prepDuration;
    });
  }

  void _startTimer() async {
    if (_isRunning) return;

    if (_totalElapsedSeconds == 0) {
      await _startRecording();
      _showTransitionBanner(_stages.first.transitionPhrase);
    }

    setState(() {
      _isRunning = true;
    });

    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_totalElapsedSeconds >= totalDuration) {
        _stopTimer();
        _triggerHardBeep();
        _attemptCount++;
        _showRubricThenSave();
      } else {
        setState(() {
          _totalElapsedSeconds++;
        });

        // Check if transition to next stage occurred
        int acc = 0;
        for (int i = 0; i < _stages.length; i++) {
          acc += _stages[i].durationSeconds;
          if (_totalElapsedSeconds == acc && _totalElapsedSeconds < totalDuration) {
            _triggerStageBeep();
            final nextStage = _stages[i + 1];
            _showTransitionBanner(nextStage.transitionPhrase);
            break;
          }
        }
      }
    });
  }

  void _stopTimer() {
    _timer?.cancel();
    setState(() {
      _isRunning = false;
    });
  }

  void _resetTimer() async {
    _stopTimer();
    _cancelPrep();
    await _stopRecording();
    setState(() {
      _totalElapsedSeconds = 0;
      _bannerText = null;
      _currentTopic = null;
    });
  }

  Future<void> _showRubricThenSave() async {
    await _stopRecording();
    if (!mounted) return;

    final checklist = [
      'Covered introduction and clear stance',
      'Elaborated points with at least one concrete example',
      'Wrapped up before the final buzzer',
      'Kept hesitations/fillers under control',
    ];
    final checked = List<bool>.filled(checklist.length, false);

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('Self-Assessment'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Quick check before you save:',
                style: TextStyle(color: Colors.grey),
              ),
              const SizedBox(height: 4),
              ...List.generate(checklist.length, (i) {
                return CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  controlAffinity: ListTileControlAffinity.leading,
                  dense: true,
                  value: checked[i],
                  title: Text(checklist[i], style: const TextStyle(fontSize: 14)),
                  onChanged: (v) => setDialogState(() => checked[i] = v ?? false),
                );
              }),
            ],
          ),
          actions: [
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Continue'),
            ),
          ],
        ),
      ),
    );

    if (!mounted) return;
    _showSaveDialog();
  }

  Future<void> _showSaveDialog() async {
    await _stopRecording();
    final textController = TextEditingController(
      text: 'MUET_Presentation_${DateTime.now().millisecondsSinceEpoch % 10000}',
    );

    if (!mounted) return;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('Save Recording'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: textController,
              decoration: const InputDecoration(
                hintText: 'Enter recording name',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
            },
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final scaffoldMessenger = ScaffoldMessenger.of(context);
              final nav = Navigator.of(ctx);

              if (_tempAudioPath != null && File(_tempAudioPath!).existsSync()) {
                final appDir = await getApplicationDocumentsDirectory();
                final fileName = '${textController.text.trim()}.m4a';
                final savedFile =
                    await File(_tempAudioPath!).copy('${appDir.path}/$fileName');
                widget.onRecordingSaved(savedFile);
              }

              if (ctx.mounted) {
                nav.pop();
                scaffoldMessenger.showSnackBar(
                  const SnackBar(content: Text('Recording saved successfully!')),
                );
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentStage = _stages[_currentStageIndex];
    final stageElapsed = _currentStageElapsedSeconds;
    final remainingTime = totalDuration - _totalElapsedSeconds;
    final intervalDisplay =
        _totalElapsedSeconds == 0 ? '0/5' : '${_currentStageIndex + 1}/5';
    final hideStageDetails = _ghostLevel == GhostLevel.silent && _isRunning;

    return SafeArea(
      child: Column(
        children: [
          // Ghost Mode toggle + attempt counter
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(Icons.visibility_off_outlined, size: 18, color: Colors.grey),
                    const SizedBox(width: 6),
                    const Text('Ghost Mode', style: TextStyle(fontWeight: FontWeight.w600)),
                    Switch(
                      value: _ghostModeEnabled,
                      onChanged: (v) => setState(() => _ghostModeEnabled = v),
                    ),
                  ],
                ),
                Text('Attempt: $_attemptCount', style: const TextStyle(color: Colors.grey)),
              ],
            ),
          ),

          // Header Card with Stage & Primary Interval Clock
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 32),
            decoration: const BoxDecoration(
              color: Colors.lightBlue,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(36),
                bottomRight: Radius.circular(36),
              ),
            ),
            child: Column(
              children: [
                Text(
                  hideStageDetails ? 'Speaking…' : currentStage.title,
                  style: const TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  _isPrepping ? _formatTime(_prepRemaining) : _formatTime(stageElapsed),
                  style: const TextStyle(
                    fontSize: 64,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2.0,
                    color: Colors.white,
                  ),
                ),
                if (_isPrepping)
                  const Padding(
                    padding: EdgeInsets.only(top: 4),
                    child: Text(
                      'PREP TIME — read your topic',
                      style: TextStyle(color: Colors.white70, fontSize: 12, letterSpacing: 1),
                    ),
                  ),
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 250),
                  child: _bannerText != null && !_isPrepping
                      ? Padding(
                          key: ValueKey(_bannerText),
                          padding: const EdgeInsets.only(top: 10, left: 24, right: 24),
                          child: Text(
                            '"${_bannerText!}"',
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Colors.white,
                              fontStyle: FontStyle.italic,
                              fontSize: 14,
                            ),
                          ),
                        )
                      : const SizedBox.shrink(),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Topic Generator
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Card(
              margin: EdgeInsets.zero,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('MUET Part 1 Topic', style: TextStyle(fontWeight: FontWeight.bold)),
                        Row(
                          children: [
                            if (_currentTopic != null && !_isRunning && !_isPrepping)
                              IconButton(
                                icon: const Icon(Icons.close, size: 18),
                                onPressed: _clearTopic,
                                tooltip: 'Clear topic',
                              ),
                            TextButton.icon(
                              onPressed: (_isRunning || _isPrepping) ? null : _pickNewTopic,
                              icon: const Icon(Icons.shuffle, size: 16),
                              label: const Text('New Topic'),
                            ),
                          ],
                        ),
                      ],
                    ),
                    Text(
                      _currentTopic ?? 'Tap "New Topic" for a random past-year prompt.',
                      style: TextStyle(
                        color: _currentTopic == null ? Colors.grey : Colors.black87,
                      ),
                    ),
                    if (_currentTopic != null && !_isRunning && _totalElapsedSeconds == 0)
                      Align(
                        alignment: Alignment.centerRight,
                        child: _isPrepping
                            ? TextButton(
                                onPressed: _cancelPrep,
                                child: const Text('Cancel Prep'),
                              )
                            : ElevatedButton.icon(
                                onPressed: _startPrep,
                                icon: const Icon(Icons.menu_book, size: 16),
                                label: const Text('Start Prep (1 min)'),
                              ),
                      ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),

          // 3-Metric Display Bar
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildMetricColumn('ELAPSED', _formatTime(_totalElapsedSeconds)),
                _buildMetricColumn('INTERVALS', hideStageDetails ? '?/5' : intervalDisplay),
                _buildMetricColumn('REMAINING', _formatTime(remainingTime)),
              ],
            ),
          ),
          const Spacer(),

          // Start/Stop and Reset Action Buttons
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 30.0),
            child: Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _isRunning ? Colors.deepOrange : Colors.orange,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                    ),
                    onPressed: _isPrepping
                        ? null
                        : (_isRunning
                            ? _stopTimer
                            : (_currentTopic != null && _totalElapsedSeconds == 0
                                ? null // must use "Start Prep" when a topic is loaded
                                : _startTimer)),
                    child: Text(
                      _isRunning ? 'Stop' : 'Start',
                      style: const TextStyle(fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(width: 20),
                Expanded(
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                    ),
                    onPressed: _resetTimer,
                    child: const Text(
                      'Reset',
                      style: TextStyle(fontSize: 20, color: Colors.black87),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Save Button
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 30.0),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black87,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                ),
                onPressed: _totalElapsedSeconds > 0 && !_isPrepping
                    ? () {
                        if (_totalElapsedSeconds >= totalDuration) {
                          _attemptCount++;
                        }
                        _showRubricThenSave();
                      }
                    : null,
                child: const Text(
                  'Save',
                  style: TextStyle(fontSize: 20, color: Colors.white),
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _buildMetricColumn(String label, String value) {
    return Column(
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey),
        ),
        const SizedBox(height: 6),
        Text(
          value,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87),
        ),
      ],
    );
  }
}

class RecordingsListScreen extends StatefulWidget {
  final List<File> recordings;

  const RecordingsListScreen({super.key, required this.recordings});

  @override
  State<RecordingsListScreen> createState() => _RecordingsListScreenState();
}

class _RecordingsListScreenState extends State<RecordingsListScreen> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  String? _currentlyPlayingPath;
  bool _isPlaying = false;

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  Future<void> _togglePlay(String path) async {
    if (_isPlaying && _currentlyPlayingPath == path) {
      await _audioPlayer.pause();
      setState(() => _isPlaying = false);
    } else {
      await _audioPlayer.stop();
      await _audioPlayer.play(DeviceFileSource(path));
      setState(() {
        _currentlyPlayingPath = path;
        _isPlaying = true;
      });

      _audioPlayer.onPlayerComplete.listen((_) {
        setState(() {
          _isPlaying = false;
          _currentlyPlayingPath = null;
        });
      });
    }
  }

  void _shareFile(String path) {
    Share.shareXFiles([XFile(path)], text: 'My MUET Speaking Practice Recording');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('List', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.lightBlue,
        foregroundColor: Colors.white,
      ),
      body: widget.recordings.isEmpty
          ? const Center(
              child: Text(
                'No recordings yet.\nRecord and save your presentation in the Timer tab!',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey, fontSize: 16),
              ),
            )
          : ListView.separated(
              itemCount: widget.recordings.length,
              separatorBuilder: (context, index) => const Divider(height: 1),
              itemBuilder: (context, index) {
                final file = widget.recordings[index];
                final fileName = file.path.split('/').last.replaceAll('.m4a', '');
                final isCurrent = _currentlyPlayingPath == file.path && _isPlaying;

                return ListTile(
                  leading: CircleAvatar(
                    backgroundColor: isCurrent ? Colors.deepOrange : Colors.lightBlue,
                    child: IconButton(
                      icon: Icon(isCurrent ? Icons.pause : Icons.play_arrow, color: Colors.white),
                      onPressed: () => _togglePlay(file.path),
                    ),
                  ),
                  title: Text(
                    fileName,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text('Recorded on: ${File(file.path).lastModifiedSync().toString().substring(0, 16)}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.insights, color: Colors.deepPurple),
                        tooltip: 'Analyze speech',
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => AnalysisResultScreen(
                                audioPath: file.path,
                                title: fileName,
                              ),
                            ),
                          );
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.share, color: Colors.lightBlue),
                        onPressed: () => _shareFile(file.path),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}