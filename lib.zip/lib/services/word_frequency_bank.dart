/// A compact list of ~300 of the most frequent words in English, used as a
/// cheap, fully offline proxy for "Band A: very common vocabulary."
///
/// This is NOT a real corpus-derived frequency table (e.g. SUBTLEXus or the
/// Google 10,000 English list) — it's a hand-picked shortlist of common
/// function words and everyday content words. It's good enough to flag
/// "this speech leans heavily on basic words" vs "this speech reaches for
/// less common vocabulary," but it is a heuristic, not a calibrated
/// frequency lookup. For a more rigorous version, bundle a real frequency
/// list as a JSON/CSV asset and rank words by their actual corpus rank
/// instead of splitting on word length.
const Set<String> kCommonWordBank = {
  // Function words / pronouns / determiners
  'the', 'be', 'to', 'of', 'and', 'a', 'in', 'that', 'have', 'i', 'it', 'for',
  'not', 'on', 'with', 'he', 'as', 'you', 'do', 'at', 'this', 'but', 'his',
  'by', 'from', 'they', 'we', 'say', 'her', 'she', 'or', 'an', 'will', 'my',
  'one', 'all', 'would', 'there', 'their', 'what', 'so', 'up', 'out', 'if',
  'about', 'who', 'get', 'which', 'go', 'me', 'when', 'make', 'can', 'like',
  'no', 'just', 'him', 'know', 'take', 'into', 'your', 'some', 'could',
  'them', 'see', 'other', 'than', 'then', 'now', 'look', 'only', 'come',
  'its', 'over', 'think', 'also', 'back', 'after', 'use', 'two', 'how',
  'our', 'well', 'even', 'new', 'want', 'because', 'any', 'these', 'give',
  'most', 'us', 'is', 'was', 'are', 'been', 'has', 'had', 'were', 'said',
  'did', 'going', 'more', 'may', 'must', 'should', 'each', 'such', 'own',
  'same', 'few', 'many', 'much', 'here', 'why', 'again', 'off', 'once',

  // Everyday content words
  'time', 'people', 'year', 'good', 'day', 'work', 'way', 'first', 'part',
  'life', 'world', 'school', 'state', 'family', 'student', 'group',
  'country', 'problem', 'hand', 'place', 'case', 'week', 'company',
  'system', 'program', 'question', 'government', 'number', 'night',
  'point', 'home', 'water', 'room', 'mother', 'area', 'money', 'story',
  'fact', 'month', 'lot', 'right', 'study', 'book', 'eye', 'job', 'word',
  'business', 'issue', 'side', 'kind', 'head', 'house', 'service',
  'friend', 'father', 'power', 'hour', 'game', 'line', 'end', 'member',
  'law', 'car', 'city', 'community', 'name', 'team', 'minute', 'idea',
  'body', 'information', 'parent', 'face', 'others', 'level', 'office',
  'door', 'health', 'person', 'art', 'history', 'result', 'change',
  'morning', 'reason', 'research', 'girl', 'guy', 'moment', 'air',
  'teacher', 'education', 'foot', 'boy', 'age', 'plan', 'college',
  'interest', 'experience', 'effect', 'food', 'rate', 'movement', 'style',
  'energy', 'plant', 'tree', 'road', 'kid', 'table', 'cost', 'care',
  'model', 'price', 'science', 'purpose', 'growth', 'image',
  'relationship', 'technology', 'source', 'film', 'dog', 'decision',
  'action', 'letter', 'mind', 'size', 'animal', 'difference', 'choice',
  'view', 'unit', 'activity', 'phone', 'doctor', 'chance', 'order',
  'offer', 'million',

  // Common verbs
  'tell', 'ask', 'seem', 'feel', 'try', 'leave', 'call', 'need', 'mean',
  'keep', 'let', 'begin', 'help', 'talk', 'turn', 'start', 'might', 'show',
  'hear', 'play', 'run', 'move', 'live', 'believe', 'bring', 'happen',
  'write', 'provide', 'sit', 'stand', 'lose', 'pay', 'meet', 'include',
  'continue', 'set', 'learn', 'lead', 'understand', 'watch', 'follow',
  'stop', 'create', 'speak', 'read', 'allow', 'add', 'spend', 'grow',
  'open', 'walk', 'win', 'remember', 'love', 'consider', 'appear', 'buy',
  'wait', 'serve', 'die', 'send', 'expect', 'build', 'stay', 'fall', 'cut',
  'reach', 'kill', 'remain',

  // Common connectors / discourse words (still "basic," unlike the
  // academic-vocabulary bank in SpeechAnalysisService)
  'however', 'actually', 'though', 'although', 'either', 'neither', 'both',
  'since', 'while', 'until', 'unless', 'whether', 'thus', 'hence',
  'perhaps', 'especially', 'generally', 'particularly', 'usually', 'often',
  'sometimes', 'always', 'never', 'rarely', 'mostly', 'quite', 'very',
  'really', 'fairly', 'pretty', 'basically',
};