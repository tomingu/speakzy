import 'dart:math';
import 'package:audioplayers/audioplayers.dart';
import 'package:whisper_ggml/whisper_ggml.dart';
import 'word_frequency_bank.dart';

/// Result of analyzing a saved practice recording[cite: 6].
class SpeechMetrics {
  final String transcript;
  final int wordCount;
  final Duration audioDuration;
  final double wpm;
  final Map<String, int> fillerCounts;
  final int totalFillers;
  final List<Duration> longPauseTimestamps;
  final List<String> vocabularyHits;

  // Lexical diversity + word-frequency-band stats[cite: 6].
  final int uniqueWordCount;
  final double typeTokenRatio; // unique / total, 0-1
  final double correctedTtr; // unique / sqrt(2*total)
  final double commonWordRatio; // Band A
  final double midWordRatio; // Band B
  final double advancedWordRatio; // Band C

  SpeechMetrics({
    required this.transcript,
    required this.wordCount,
    required this.audioDuration,
    required this.wpm,
    required this.fillerCounts,
    required this.totalFillers,
    required this.longPauseTimestamps,
    required this.vocabularyHits,
    required this.uniqueWordCount,
    required this.typeTokenRatio,
    required this.correctedTtr,
    required this.commonWordRatio,
    required this.midWordRatio,
    required this.advancedWordRatio,
  });

  static const int targetWpmMin = 110;
  static const int targetWpmMax = 140;

  bool get paceInRange => wpm >= targetWpmMin && wpm <= targetWpmMax;

  String get paceLabel {
    if (wpm < 90) return 'Too slow — aim for $targetWpmMin–$targetWpmMax wpm';
    if (wpm < targetWpmMin) return 'A little slow — pick up the pace slightly';
    if (wpm <= targetWpmMax) return 'Great pace!';
    if (wpm <= 160) return 'A little fast — slow down slightly';
    return 'Too fast — slow down and pause between points';
  }

  String get lexicalDiversityLabel {
    if (correctedTtr < 6) return 'Limited range — try varying your word choice more';
    if (correctedTtr < 9) return 'Moderate vocabulary variety';
    return 'Strong vocabulary variety';
  }
}

/// Transcribes a recording on-device and derives MUET-relevant speech metrics[cite: 6].
class SpeechAnalysisService {
  static const List<String> fillerWords = [
    'um',
    'uh',
    'erm',
    'uhm',
    'like',
    'you know',
  ];

  static const List<String> vocabularyBank = [
    'furthermore',
    'moreover',
    'nevertheless',
    'nonetheless',
    'consequently',
    'in conclusion',
    'on the other hand',
    'in addition',
    'however',
    'therefore',
    'to summarize',
    'in summary',
    'notably',
    'significantly',
    'arguably',
    'undoubtedly',
    'conversely',
    'substantial',
    'predominantly',
    'ubiquitous',
    'inevitable',
    'controversial',
    'beneficial',
    'detrimental',
    'feasible',
    'comprehensive',
    'crucial',
    'fundamental',
    'considerable',
  ];

  static const Duration longPauseThreshold = Duration(seconds: 2);

  Future<SpeechMetrics> analyze(
    String audioPath, {
    WhisperModel model = WhisperModel.base,
    void Function(int percent)? onProgress,
  }) async {
    final duration = await _getAudioDuration(audioPath);

    final controller = WhisperController();
    final result = await controller.transcribe(
      model: model,
      audioPath: audioPath,
      lang: 'en',
      withSegments: true,
      splitOnWord: true,
      onProgress: onProgress,
    );

    final transcript = (result?.transcription.text ?? '').trim();
    final words =
        transcript.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    final wordCount = words.length;

    final minutes = duration.inMilliseconds / 60000.0;
    final wpm = minutes > 0 ? wordCount / minutes : 0.0;

    final fillerCounts = <String, int>{};
    for (final filler in fillerWords) {
      final pattern =
          RegExp(r'\b' + RegExp.escape(filler) + r'\b', caseSensitive: false);
      final count = pattern.allMatches(transcript).length;
      if (count > 0) fillerCounts[filler] = count;
    }
    final totalFillers = fillerCounts.values.fold<int>(0, (a, b) => a + b);

    final longPauses = <Duration>[];
    final segments = result?.transcription.segments ?? [];
    for (int i = 0; i < segments.length - 1; i++) {
      final gap = segments[i + 1].fromTs - segments[i].toTs;
      if (gap >= longPauseThreshold) {
        longPauses.add(segments[i].toTs);
      }
    }

    final vocabHits = <String>[];
    for (final term in vocabularyBank) {
      final pattern =
          RegExp(r'\b' + RegExp.escape(term) + r'\b', caseSensitive: false);
      if (pattern.hasMatch(transcript)) vocabHits.add(term);
    }

    final lexicalStats = _computeLexicalStats(transcript);

    return SpeechMetrics(
      transcript: transcript,
      wordCount: wordCount,
      audioDuration: duration,
      wpm: wpm,
      fillerCounts: fillerCounts,
      totalFillers: totalFillers,
      longPauseTimestamps: longPauses,
      vocabularyHits: vocabHits,
      uniqueWordCount: lexicalStats.uniqueWordCount,
      typeTokenRatio: lexicalStats.typeTokenRatio,
      correctedTtr: lexicalStats.correctedTtr,
      commonWordRatio: lexicalStats.commonWordRatio,
      midWordRatio: lexicalStats.midWordRatio,
      advancedWordRatio: lexicalStats.advancedWordRatio,
    );
  }

  _LexicalStats _computeLexicalStats(String transcript) {
    final cleaned = transcript
        .toLowerCase()
        .replaceAll(RegExp(r"[^a-z' ]"), ' ')
        .split(RegExp(r'\s+'))
        .map((w) => w.trim())
        .where((w) => w.isNotEmpty)
        .toList();

    final total = cleaned.length;
    if (total == 0) {
      return _LexicalStats(
        uniqueWordCount: 0,
        typeTokenRatio: 0,
        correctedTtr: 0,
        commonWordRatio: 0,
        midWordRatio: 0,
        advancedWordRatio: 0,
      );
    }

    final uniqueWords = cleaned.toSet();
    final ttr = uniqueWords.length / total;
    final cttr = uniqueWords.length / sqrt(2 * total);

    int bandA = 0;
    int bandB = 0;
    int bandC = 0;
    for (final w in cleaned) {
      if (kCommonWordBank.contains(w)) {
        bandA++;
      } else if (w.length <= 6) {
        bandB++;
      } else {
        bandC++;
      }
    }

    return _LexicalStats(
      uniqueWordCount: uniqueWords.length,
      typeTokenRatio: ttr,
      correctedTtr: cttr,
      commonWordRatio: bandA / total,
      midWordRatio: bandB / total,
      advancedWordRatio: bandC / total,
    );
  }

  Future<Duration> _getAudioDuration(String path) async {
    final player = AudioPlayer();
    try {
      await player.setSourceDeviceFile(path);
      final d = await player.getDuration();
      return d ?? const Duration(seconds: 120);
    } finally {
      await player.dispose();
    }
  }
}

class _LexicalStats {
  final int uniqueWordCount;
  final double typeTokenRatio;
  final double correctedTtr;
  final double commonWordRatio;
  final double midWordRatio;
  final double advancedWordRatio;

  _LexicalStats({
    required this.uniqueWordCount,
    required this.typeTokenRatio,
    required this.correctedTtr,
    required this.commonWordRatio,
    required this.midWordRatio,
    required this.advancedWordRatio,
  });
}